import speak
import wikipedia
import pywhatkit
from listen import Listen

def InputExecution(tag,query):

    if "wikipedia" in tag:
        taffer = str(query).replace("who is","").replace("what is","").replace("wikipedia","")
        result = wikipedia.summary(taffer)
        speak.say(result)

   
    elif "email" in tag:
         speak.say("please enter sender's email id in your pc terminal")
         sender = input()
         speak.say("please enter the password,it is safe don't worry")
         password= input()
         speak.say("what is the subject")
         subject= Listen()
         speak.say("what is the content")
         content= Listen()
         speak.say ("please enter the receiver email id in your computer terminal")
         receiver= input()
         pywhatkit.send_mail(sender,password,subject,content,receiver)

    elif "youtube" in tag:
        speak.say ("what should i play")
        you= Listen() 
        pywhatkit.playonyt(f"{you}")
        speak.say("playing" + f"{you}")




    
    